#pragma once
#include<string>
class HashManager {
  private:
    char str[50];
  public:
    void print_hashes();
    HashManager();
    
};
