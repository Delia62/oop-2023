#include"HashManager.h"

void HashManager::print_hashes() {
	
}